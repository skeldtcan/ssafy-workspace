package com.ssafy.java.day1.hw;

import java.util.Scanner;

public class CircleArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r = 5;
		float pi = 3.14F;
		System.out.printf("반지름 %dCm인 원의 넓이는 %.1fcm2입니다.\n", r, r*r*pi);		
	}
}
