<template>
  <div>
    <h2 class="text-center">게시글 등록</h2>
    <table class=" table table-condensed w-25 ">
      <tr>
        <th>id</th>
        <td>
          <input
            type="text"
            id="id"
            v-model="id"
            ref="id"
            placeholder="아이디를 입력해주세요"
          />
        </td>
      </tr>
      <tr>
        <th>이름</th>
        <td>
          <input
            type="text"
            id="name"
            v-model="name"
            ref="name"
            placeholder="이름을 입력해주세요"
          />
        </td>
      </tr>
      <tr>
        <th>mail</th>
        <td>
          <input
            type="text"
            id="mailid"
            v-model="mailid"
            ref="mailid"
            placeholder="8자 이하 mail을 입력해주세요"
          />
        </td>
      </tr>
      <tr>
        <th>입사일</th>
        <td>
          <input
            type="date"
            id="start_date"
            v-model="start_date"
            ref="start_date"
            placeholder="입사일을 입력해주세요"
          />
        </td>
      </tr>
      <tr>
        <th>매니저 id</th>
        <td>
          <input
            type="text"
            id="manager_id"
            v-model="manager_id"
            ref="manager_id"
            placeholder="매니저 id를 입력해주세요"
          />
        </td>
      </tr>
      <tr>
        <th>직급</th>
        <td>
          <input
            type="text"
            id="title"
            v-model="title"
            ref="title"
            placeholder="직급을 입력해주세요"
          />
        </td>
      </tr>
      <tr>
        <th>부서번호</th>
        <td>
          <input
            type="text"
            id="dept_id"
            v-model="dept_id"
            ref="dept_id"
            placeholder="부서번호를 입력해주세요"
          />
        </td>
      </tr>
      <tr>
        <th>연봉</th>
        <td>
          <input
            type="text"
            id="salary"
            v-model="salary"
            ref="salary"
            placeholder="연봉을 입력해주세요"
          />
        </td>
      </tr>
      <tr>
        <th>커미션</th>
        <td>
          <input
            type="text"
            id="commision_pct"
            v-model="commision_pct"
            ref="commision_pct"
            placeholder="커미션을 입력해주세요"
          />
        </td>
      </tr>
    </table>

    <div class="text-right">
      <button class="btn btn-primary" @click="createHandler">등록</button>
      <button class="btn btn-primary" @click="moveHandler">목록</button>
    </div>
  </div>
</template>
<script>
import axios from 'axios';

export default {
  data() {
    return {
      id: '',
      name: '',
      mailid: '',
      start_date: '',
      manager_id: '',
      title: '',
      dept_id: '',
      salary: '',
      commision_pct: '',
    };
  },
  methods: {
    createHandler: function() {
      let err = true;
      let msg = '';

      //필수 요건 검사
      !this.id &&
        ((msg = 'id를 입력해 주세요'), (err = false), this.$refs.id.focus());
      err &&
        !this.name &&
        ((msg = '이름을 입력해 주세요'),
        (err = false),
        this.$refs.name.focus());
      err &&
        !this.mailid &&
        ((msg = '메일을 입력해 주세요'),
        (err = false),
        this.$refs.mailid.focus());
      err &&
        !this.start_date &&
        ((msg = '입사일을 입력해 주세요'),
        (err = false),
        this.$refs.start_date.focus());
      err &&
        !this.manager_id &&
        ((msg = '매니저 아이디를 입력해 주세요'),
        (err = false),
        this.$refs.manager_id.focus());
      err &&
        !this.title &&
        ((msg = '직급을 입력해 주세요'),
        (err = false),
        this.$refs.title.focus());
      err &&
        !this.dept_id &&
        ((msg = '부서번호를 입력해 주세요'),
        (err = false),
        this.$refs.dept_id.focus());
      err &&
        !this.salary &&
        ((msg = '연봉을 입력해 주세요'),
        (err = false),
        this.$refs.salary.focus());
      err &&
        !this.commision_pct &&
        ((msg = '커미션을 입력해 주세요'),
        (err = false),
        this.$refs.commision_pct.focus());

      if (!err) alert(msg);
      else {
        //server에 등록 요청
        axios
          .post('http://localhost:8097/hrmboot/api/employee', {
            id: this.id,
            name: this.name,
            mailid: this.mailid,
            start_date: this.start_date,
            manager_id: this.manager_id,
            title: this.title,
            dept_id: this.dept_id,
            salary: this.salary,
            commision_pct: this.commision_pct,
          })
          .then((Response) => {
            alert('등록 완료!!!');
            this.moveHandler();
          })
          .catch((error) => {
            alert(error);
          });
      } // else end
    }, //function end
    moveHandler: function() {
      this.$router.push('/list');
    },
  },
};
</script>
