<template>
  <div>삭제 중....</div>
</template>
<script>
import axios from 'axios';

export default {
  created() {
    const params = new URL(document.location).searchParams;
    axios
      .delete(
        `http://localhost:8097/hrmboot/api/employee/del/${params.get('id')}`
      )
      .then((response) => {
        alert('삭제 완료!!');
        this.$router.push('/list');
      })
      .catch((error) => {
        alert('삭제 중 오류 발생!!');
        this.$router.push('/list');
      });
  },
};
</script>
