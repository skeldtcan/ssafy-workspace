import Vue from "vue";
import VueRouter from "vue-router";
import List from "../components/List.vue";
import Detail from "../components/Detail.vue";
import Create from "../components/Create.vue";
import Delete from "../components/Delete.vue";

Vue.use(VueRouter);

const routes = [
  {
    path: "/list",
    name: "list",
    component: List
  },
  {
    path: "/detail",
    name: "detail",
    component: Detail
  },
  {
    path: "/create",
    name: "create",
    component: Create
  },
  {
    path: "/delete",
    name: "delete",
    component: Delete
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

export default router;
