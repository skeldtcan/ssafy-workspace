package com.ssafy.model.service;

import java.sql.Connection;
import java.sql.SQLException;

import com.ssafy.model.dao.ProductDao;
import com.ssafy.model.dao.ProductDaoImpl;
import com.ssafy.model.dto.Product;
import com.ssafy.util.DBUtil;

public class ProductServiceImpl implements ProductService {
	
	private ProductDao productDao;
	
	public ProductServiceImpl() {
		productDao = new ProductDaoImpl();
	}
	
	public int insertProduct(Product productDto) throws Exception {
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			productDao.insertProduct(conn,productDto);
			return productDao.getLastNo(conn);
		} catch (SQLException e) {
			DBUtil.rollback(conn);
			throw new Exception("제품 등록 중 오류 발생");
		} finally {
			DBUtil.close(conn);
		}
	}

	@Override
	public Product getProduct(int productno) throws Exception {
		return productDao.getProduct(productno);
	}

	@Override
	public void delProduct(int productno) throws Exception {
		Connection conn = null;
		try {
			conn = DBUtil.getConnection();
			productDao.delProduct(conn, productno);
		} catch (SQLException e) {
			DBUtil.rollback(conn);
			throw new Exception("제품 삭제 중 오류 발생");
		} finally {
			DBUtil.close(conn);
		}
	}

}
