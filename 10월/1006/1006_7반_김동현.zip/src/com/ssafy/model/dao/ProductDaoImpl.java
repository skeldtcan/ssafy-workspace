package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ssafy.model.dto.Product;
import com.ssafy.util.DBUtil;

public class ProductDaoImpl implements ProductDao {

	@Override
	public void insertProduct(Connection conn, Product product) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("insert into product (name, price, info) \n");
			insertMember.append("values(?, ?, ?)");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, product.getName());
			pstmt.setInt(2, product.getPrice());
			pstmt.setString(3, product.getInfo());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
		}

	}

	public int getLastNo(Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql =" select LAST_INSERT_ID() as id from dual";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt("id");
			}else {
				throw new SQLException("ID 추출 오류");
			}
		}finally {
			DBUtil.close(pstmt);
		}
		
	}
	@Override
	public Product getProduct(int productno) throws SQLException {
		Product productDto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			
			sql.append(" select * \n");
			sql.append(" from product \n");
			sql.append(" where productno = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, productno);
			rs = pstmt.executeQuery();
			
			if (rs.next()) {
				productDto = new Product();
				productDto.setProductno(rs.getInt("productno"));
				productDto.setName(rs.getString("name"));
				productDto.setPrice(rs.getInt("price"));
				productDto.setInfo(rs.getString("info"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return productDto;
	}

	@Override
	public void delProduct(Connection conn, int productno) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			StringBuilder sql = new StringBuilder();
			
			sql.append(" delete from product \n");
			sql.append(" where productno = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setInt(1, productno);
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
		}
	} 

}
