package com.ssafy.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.model.dto.MemberDto;
import com.ssafy.model.dto.Product;
import com.ssafy.model.service.LoginService;
import com.ssafy.model.service.LoginServiceImpl;
import com.ssafy.model.service.ProductService;
import com.ssafy.model.service.ProductServiceImpl;

@WebServlet( "/main.do" )
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private LoginService loginService;
	private ProductService productService;
	
	@Override
	public void init() throws ServletException{
		super.init();
		loginService = new LoginServiceImpl();
		productService = new ProductServiceImpl();
	}
	


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	
	
	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		
		String action = request.getParameter("action");
		
		if("login".equals(action)) {
			login(request, response);
		} else if("logout".equals(action)) {
			logout(request, response);
		} else if("mvInsert".equals(action)) {
			response.sendRedirect(root + "/product/insert.jsp");
		} else if("list".equals(action)) {
			response.sendRedirect(root + "/product/list.jsp");
		} else if("del".equals(action)) {
			response.sendRedirect(root + "/product/del.jsp");
		} else if("insertProduct".equals(action)) {
			insertProduct(request, response);
		} else if("deleteProduct".equals(action)) {
			deleteProduct(request, response);
		} else {
			response.sendRedirect(root);
		}
	}
	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		
		try {
			MemberDto memberDto = loginService.login(userid, userpwd);
			if(memberDto != null) { // 받은 값 있으면 = 로그인 성공이면
				// session 설정
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDto);
				
				//마지막에 등록한 상품 정보가 있는지 cookie에서 확인
				Cookie cookies[] = request.getCookies();
				String no=null;			//마지막에 등록한 상품 번호
				if(cookies!=null) {
					for (Cookie cookie : cookies) {
						if(cookie.getName().equals("lastProduct")) {
							no = cookie.getValue();
						}
					}
				}
				if(no!=null) {  //등록한 상품이 있는 경우 
					Product product = productService.getProduct(Integer.parseInt(no));
					request.setAttribute("product", product);
					path = "/product/insertsuccess.jsp";
				}else {			//첫 로그인이라서 등록한 상품이 없는 경우 
					request.setAttribute("msg", "등록한 상품이 없습니다.");
				}
			} else {
				request.setAttribute("msg", "아이디 또는 비밀번호 확인 후 로그인 해주세요.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "로그인 중 문제가 발생했습니다.");
			path = "/error/error.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		session.invalidate();
		response.sendRedirect(request.getContextPath());
	}
	
	private void insertProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");
		try {
			if(memberDto != null) { //지금 로그인 되어 있으면
				Product product = new Product();
				product.setName(request.getParameter("name"));
				product.setPrice(Integer.parseInt(request.getParameter("price")));
				product.setInfo(request.getParameter("info"));
				try {
					int no = productService.insertProduct(product);
					product.setProductno(no);
//					등록한 상품을 확인하기 위해서 insertsuccess.jsp로 이동
//					insertsuccess.jsp에서 상품정보를 사용하기 위해 reqeust에 임시로 저장 
					request.setAttribute("product", product);
					path = "/product/insertsuccess.jsp";

//					등록한 상품 정보를 cookie에 담기 
					Cookie cookie = new Cookie("lastProduct", ""+no);
					cookie.setMaxAge(60*60*3);
					response.addCookie(cookie);
				} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("msg", e.getMessage());
					path = "/error/error.jsp";
				} 
			} else {
				request.setAttribute("msg", "로그인 후 사용 가능한 페이지입니다.");
				path = "/error/error.jsp";
			}
		} catch (NumberFormatException e) {
			request.setAttribute("msg","상품 등록 실패!!! 상품 가격을 정수로 입력해 주세요.");
		}
		
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	private void deleteProduct(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/index.jsp";
		HttpSession session = request.getSession();
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");
		try {
			if(memberDto != null) { //지금 로그인 되어 있으면
				try {
					int productno = Integer.parseInt(request.getParameter("productno"));
					System.out.println(productno);
					productService.delProduct(productno);
//					등록한 상품을 확인하기 위해서 insertsuccess.jsp로 이동
//					insertsuccess.jsp에서 상품정보를 사용하기 위해 reqeust에 임시로 저장 
					path = "/index.jsp";

//					등록한 상품 정보를 cookie에 담기 
					//Cookie cookie = new Cookie("lastProduct", ""+no);
					//cookie.setMaxAge(60*60*3);
					//response.addCookie(cookie);
				} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("msg", e.getMessage());
					path = "/error/error.jsp";
				} 
			} else {
				request.setAttribute("msg", "로그인 후 사용 가능한 페이지입니다.");
				path = "/error/error.jsp";
			}
		} catch (NumberFormatException e) {
			request.setAttribute("msg","상품 삭제 실패!!! 상품 번호를 정수로 입력해 주세요.");
		}
		
		request.getRequestDispatcher(path).forward(request, response);
	}
	

}
