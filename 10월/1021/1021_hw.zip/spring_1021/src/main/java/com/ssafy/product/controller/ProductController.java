package com.ssafy.product.controller;

import javax.jws.WebParam.Mode;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ssafy.product.dto.Product;
import com.ssafy.product.service.ProductService;

@Controller
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@ExceptionHandler
	public ModelAndView handler(Exception e) {
		ModelAndView mav = new ModelAndView("Error");
		mav.addObject("msg", e.getMessage());
		e.printStackTrace();
		return mav;
	}
	
	@GetMapping("/listProduct.do")
	public String listProduct(Model model) {
		model.addAttribute("list", productService.searchAll());
		return "product/listProduct"; 
	}
	
	@GetMapping("/insertProductForm.do")
	public String insertProductForm() {
		return "product/insertProduct"; 
	}
	
	@PostMapping("/insertProduct.do")
	public String insertProduct(Product product) {
		productService.insert(product);
		return "redirect:listProduct.do";
	}
	
	@GetMapping("/searchProduct.do")
	public String searchProduct(String id, Model model) {
		model.addAttribute("product", productService.search(id));
		return "product/searchProduct"; 
	}
	
	@GetMapping("/updateProductForm.do")
	public String updateProductForm(String id, Model model) {
		model.addAttribute("product", productService.search(id));
		return "product/updateProduct"; 
	}
	
	@PostMapping("/updateProduct.do")
	public String updateProduct(Product product) {
		productService.update(product);
		return "redirect:searchProduct.do?id="+product.getId();
	}
	
	@GetMapping("/removeProduct.do")
	public String removeProduct(String id) {
		productService.delete(id);
		return "redirect:listProduct.do"; 
	}
}









